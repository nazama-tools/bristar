CARA PAKAI WEBSITE BRISTAR
===========================

1. GANTI LINK GRUP TIKTOK
   Buka file index.html, cari baris ini:

   <a href="https://www.tiktok.com/" target="_blank" ...>

   Ganti "https://www.tiktok.com/" dengan link grup TikTok BRISTAR yang asli.

2. GANTI LOGO
   Masukkan file logo kamu ke folder:
   images/logo/logo.png

   Kalau nama filenya bukan "logo.png", ganti juga bagian
   src="images/logo/logo.png" di index.html (ada 2 tempat).

   Kalau belum ada logo, tampilan otomatis pakai lingkaran
   tulisan "BR" sebagai pengganti sementara.

3. BUKA WEBSITE
   Tinggal buka file index.html pakai browser (double click),
   atau upload semua file ke hosting (Netlify, Vercel, GitHub Pages, dll).

STRUKTUR FOLDER
================
bristarproject/
├── index.html
├── style.css
├── README.txt
└── images/
    └── logo/
        └── .gitkeep   (jaga folder tetap ada walau kosong, bisa dihapus setelah taruh logo)
